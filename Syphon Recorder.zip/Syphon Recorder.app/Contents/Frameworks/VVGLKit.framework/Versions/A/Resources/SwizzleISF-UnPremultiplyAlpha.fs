/*{
	"DESCRIPTION": "unpremultiplies the alpha",
	"CREDIT": "by zoidberg",
	"CATEGORIES": [
		"TEST-GLSL FX"
	],
	"INPUTS": [
		{
			"NAME": "inputImage",
			"TYPE": "image"
		},
		{
			"NAME": "blackFlag",
			"TYPE": "bool",
			"DEFAULT": 0
		}
	]
}*/

void main()
{
	vec4		returnMe = (blackFlag) ? vec4(0., 0., 0., 1.) : IMG_NORM_PIXEL(inputImage, vv_FragNormCoord).rgba;
	gl_FragColor = vec4(returnMe.r/returnMe.a, returnMe.g/returnMe.a, returnMe.b/returnMe.a, returnMe.a);
}
