/*{
	"DESCRIPTION": "",
	"CREDIT": "by zoidberg",
	"CATEGORIES": [
		"TEST-GLSL FX"
	],
	"INPUTS": [
		{
			"NAME": "inputImage",
			"TYPE": "image"
		}
	],
	"PASSES": [
		{
			"TARGET": "redHistoResult",
			"FLOAT": true
		},
		{
			"TARGET": "greenHistoResult",
			"FLOAT": true
		},
		{
			"TARGET": "blueHistoResult",
			"FLOAT": true
		},
		{
			"FLOAT": true
		}
	],
	"PERSISTENT_BUFFERS": [
		"redHistoResult",
		"greenHistoResult",
		"blueHistoResult"
	]
	
}*/




void main()
{
	
	if (PASSINDEX == 3)	{
		
		gl_FragColor = vec4(
			IMG_PIXEL(redHistoResult, gl_FragCoord.xy).r,
			IMG_PIXEL(greenHistoResult, gl_FragCoord.xy).g,
			IMG_PIXEL(blueHistoResult, gl_FragCoord.xy).b,
			1.0);
		
		//gl_FragColor = vec4(IMG_PIXEL(redHistoResult, gl_FragCoord.xy).r, 0.0, 0.0, 1.0);
		//gl_FragColor = IMG_PIXEL(inputImage, gl_FragCoord.xy);
	}
	else	{
		//gl_FragColor = vertColor;
		gl_FragColor = vec4(1,1,1,1);
	}
}
