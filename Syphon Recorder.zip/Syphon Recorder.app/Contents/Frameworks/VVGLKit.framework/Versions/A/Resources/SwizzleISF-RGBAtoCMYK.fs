/*{
	"DESCRIPTION": "swizzles RGBA to CMYK and vice versa",
	"CREDIT": "by zoidberg",
	"CATEGORIES": [
		"TEST-GLSL FX"
	],
	"INPUTS": [
		{
			"NAME": "inputImage",
			"TYPE": "image"
		},
		{
			"NAME": "blackFlag",
			"TYPE": "bool",
			"DEFAULT": 0
		}
	]
}*/




vec4 RGBAtoCMYK(vec4 inColor)
{
	/*
	vec4	cmyk;
	cmyk.xyz = 1.0 - inColor.xyz;
	cmyk.w = min(cmyk.x, min(cmyk.y, cmyk.z)); // Create K
	cmyk.xyz -= cmyk.w; // Subtract K equivalent from CMY
	return cmyk;
	*/
	vec4		ret;
	ret.w = 1.0 - max(max(inColor.x, inColor.y), inColor.z);
	ret.x = (1.0-inColor.x-ret.w)/(1.0-ret.w);
	ret.y = (1.0-inColor.y-ret.w)/(1.0-ret.w);
	ret.z = (1.0-inColor.z-ret.w)/(1.0-ret.w);
	//ret.w = min(min(ret.x, ret.y), min(ret.z, ret.w));
	return ret;
	
}
vec4 CMYKtoRGBA(vec4 inColor)
{
	vec4		ret;
	ret.xyz = (1.0-inColor.xyz)*(1.0-inColor.w);
	ret.w = 1.0;
	return ret;
}


void main()
{
	gl_FragColor = (blackFlag) ? RGBAtoCMYK(vec4(0., 0., 0., 1.)) : RGBAtoCMYK(IMG_NORM_PIXEL(inputImage, vv_FragNormCoord));
}