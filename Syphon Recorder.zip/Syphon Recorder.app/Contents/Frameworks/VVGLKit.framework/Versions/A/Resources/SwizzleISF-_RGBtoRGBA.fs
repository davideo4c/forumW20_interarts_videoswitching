/*{
	"DESCRIPTION": "swizzles no-alpha-skip-first to RGBA",
	"CREDIT": "by zoidberg",
	"CATEGORIES": [
		"TEST-GLSL FX"
	],
	"INPUTS": [
		{
			"NAME": "inputImage",
			"TYPE": "image"
		},
		{
			"NAME": "blackFlag",
			"TYPE": "bool",
			"DEFAULT": 0
		}
	]
}*/

void main()
{
	gl_FragColor = (blackFlag) ? vec4(0., 0., 0., 1.) : vec4(IMG_NORM_PIXEL(inputImage, vv_FragNormCoord).gba, 1.0);
}
