uniform vec4			_VVCanvasRect;
uniform int				_premultFlag;
varying vec4			_VVGLPos;
const float			_aaTol = 2.0;
PUT_VARDEC_HERE

PUT_FUNCDEC_HERE
float AntiAliasMultiplier(mat4 transMat, vec2 canvasLoc, vec4 cropRect);

void main()	{
	vec4		canvasCoords = vec4((_VVCanvasRect.x + (((_VVGLPos.x + 1.0)/2.0)*_VVCanvasRect.z)), (_VVCanvasRect.y + (((_VVGLPos.y + 1.0)/2.0)*_VVCanvasRect.w)), 0.0, 1.0);
	vec4		tmpPixelCoords;
	vec4		tmpPixelVal;
	float		tmpAAMultiplier;
	bool		sampledAPixel = false;
	vec4		cumulativePixelVal = vec4(0.0, 0.0, 0.0, 0.0);
	
PUT_STEPS_HERE
	
	gl_FragColor = (_premultFlag>0) ? vec4(cumulativePixelVal.r*cumulativePixelVal.a, cumulativePixelVal.g*cumulativePixelVal.a, cumulativePixelVal.b*cumulativePixelVal.a, cumulativePixelVal.a) : cumulativePixelVal;
}

PUT_FUNCTIONS_HERE
float AntiAliasMultiplier(mat4 transMat, vec2 canvasLoc, vec4 crop)	{
	vec4		pixel;
	float		count = 0.0;
	float		row;
	float		col;
	for (row=-1.0; row<=1.0; row+=2.0)	{
		for (col=-1.0; col<=1.0; col+=2.0)	{
			pixel = transMat * vec4((canvasLoc+vec2(col,row)), 0.0, 1.0);
			pixel = vec4(pixel.x/pixel.w, pixel.y/pixel.w, pixel.z, pixel.w);
			if (pixel.x>=crop.x && pixel.x<crop.z && pixel.y>=crop.y && pixel.y<crop.w)	{
				count += 1.0;
			}
		}
	}
	if (count==0.0 || count==4.0)
		return (count/4.0);
	count = 0.0;
	for (row=-0.5; row<=0.5; row+=0.25)	{
		for (col=-0.5; col<=0.5; col+=0.25)	{
			pixel = transMat * vec4(canvasLoc+vec2(col,row), 0.0, 1.0);
			pixel = vec4(pixel.x/pixel.w, pixel.y/pixel.w, pixel.z, pixel.w);
			if (pixel.x>=crop.x && pixel.x<crop.z && pixel.y>=crop.y && pixel.y<crop.w)
				count += 1.0;
		}
	}
	return (count/25.0);
}
