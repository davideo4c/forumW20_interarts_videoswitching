/*{
	"DESCRIPTION": "swizzles RGBA to luma",
	"CREDIT": "by zoidberg",
	"CATEGORIES": [
		"TEST-GLSL FX"
	],
	"INPUTS": [
		{
			"NAME": "inputImage",
			"TYPE": "image"
		},
		{
			"NAME": "blackFlag",
			"TYPE": "bool",
			"DEFAULT": 0
		}
	]
	
}*/

const vec4 lumacoeff = vec4(0.2126,0.7152,0.0722, 0.0);

void main()
{
	vec4	color = (blackFlag) ? vec4(0., 0., 0., 1.) : IMG_THIS_NORM_PIXEL(inputImage);
	//color.a = 1.0;
	float	lum = dot(color, lumacoeff);
	gl_FragColor = vec4(lum,lum,lum,1.0);
}
