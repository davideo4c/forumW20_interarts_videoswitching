vec4 CompositeBottomAndTop(vec4 bottom, float bottomAlpha, vec4 top, float topAlpha)
{
	
	float		TA = (topAlpha*top.a);
	vec4		DT = top * vec4(TA);
	//vec4		DT = top * vec4(topAlpha);
	DT.a = TA;
	
	vec4		returnMe;
	//returnMe = bottom*vec4(bottom.a) + DT;
	returnMe = bottom + DT;
	returnMe.a = max(bottom.a, TA);
	
	return returnMe;
	
	
	
	
	/*
	vec4		darkenedBottom = vec4(bottomAlpha) * bottom;
	vec4		returnMe = darkenedBottom + (vec4(topAlpha) * top);
	returnMe.a = 1.0;
	return returnMe;
	*/
}


vec4 CompositeBottom(vec4 bottom, float bottomAlpha)	{
	//return vec4(bottom.r, bottom.g, bottom.b, bottom.a*bottomAlpha);
	//return vec4(bottomAlpha)*bottom;
	vec4		returnMe;
	returnMe = vec4(bottomAlpha)*bottom;
	//returnMe.a = 1.0;
	returnMe.a = bottom.a*bottomAlpha;
	return returnMe;
}
vec4 CompositeTop(vec4 top, float topAlpha)	{
	vec4		returnMe = vec4(topAlpha)*top;
	return returnMe;
}
